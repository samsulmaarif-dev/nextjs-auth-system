(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_364b309d._.js",
  "static/chunks/f742d_next_dist_compiled_react-dom_ebb5eda5._.js",
  "static/chunks/f742d_next_dist_compiled_next-devtools_index_79ed61dd.js",
  "static/chunks/f742d_next_dist_compiled_6849ad1e._.js",
  "static/chunks/f742d_next_dist_client_2db6e932._.js",
  "static/chunks/f742d_next_dist_56339ecb._.js",
  "static/chunks/69652_@swc_helpers_cjs_77b72907._.js"
],
    source: "entry"
});
